const form = document.getElementById("transaction-form");
const descriptionInput = document.getElementById("description");
const amountInput = document.getElementById("amount");
const typeInput = document.getElementById("type");
const balanceElement = document.getElementById("balance");
const incomeElement = document.getElementById("income");
const expensesElement = document.getElementById("expenses");
const transactionList = document.getElementById("transaction-list");
const emptyState = document.getElementById("empty-state");
const clearAllButton = document.getElementById("clear-all");

const STORAGE_KEY = "student-expense-tracker-transactions";
let transactions = loadTransactions();

function loadTransactions() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    return Array.isArray(saved) ? saved : [];
  } catch {
    return [];
  }
}

function saveTransactions() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(transactions));
}

function formatCurrency(value) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    minimumFractionDigits: 2
  }).format(value);
}

function updateSummary() {
  const income = transactions
    .filter(item => item.type === "income")
    .reduce((total, item) => total + item.amount, 0);

  const expenses = transactions
    .filter(item => item.type === "expense")
    .reduce((total, item) => total + item.amount, 0);

  incomeElement.textContent = formatCurrency(income);
  expensesElement.textContent = formatCurrency(expenses);
  balanceElement.textContent = formatCurrency(income - expenses);
}

function renderTransactions() {
  transactionList.replaceChildren();
  emptyState.hidden = transactions.length > 0;

  [...transactions].reverse().forEach(transaction => {
    const item = document.createElement("li");
    item.className = "transaction-item";

    const info = document.createElement("div");
    info.className = "transaction-info";

    const icon = document.createElement("span");
    icon.className = "transaction-icon";
    icon.textContent = transaction.type === "income" ? "+" : "−";
    icon.setAttribute("aria-hidden", "true");

    const details = document.createElement("div");
    const name = document.createElement("div");
    name.className = "transaction-name";
    name.textContent = transaction.description;

    const date = document.createElement("div");
    date.className = "transaction-date";
    date.textContent = new Date(transaction.createdAt).toLocaleString("en-IN", {
      dateStyle: "medium",
      timeStyle: "short"
    });

    details.append(name, date);
    info.append(icon, details);

    const right = document.createElement("div");
    right.className = "transaction-right";

    const amount = document.createElement("span");
    amount.className = `transaction-amount ${transaction.type}`;
    amount.textContent = `${transaction.type === "income" ? "+" : "−"}${formatCurrency(transaction.amount)}`;

    const deleteButton = document.createElement("button");
    deleteButton.className = "delete-button";
    deleteButton.type = "button";
    deleteButton.textContent = "Delete";
    deleteButton.setAttribute("aria-label", `Delete ${transaction.description}`);
    deleteButton.addEventListener("click", () => {
      transactions = transactions.filter(entry => entry.id !== transaction.id);
      saveTransactions();
      render();
    });

    right.append(amount, deleteButton);
    item.append(info, right);
    transactionList.append(item);
  });

  updateSummary();
}

function render() {
  renderTransactions();
}

form.addEventListener("submit", event => {
  event.preventDefault();

  const description = descriptionInput.value.trim();
  const amount = Number(amountInput.value);
  const type = typeInput.value;

  if (!description || !Number.isFinite(amount) || amount <= 0) {
    alert("Please enter a transaction name and an amount greater than zero.");
    return;
  }

  transactions.push({
    id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    description,
    amount,
    type,
    createdAt: new Date().toISOString()
  });

  saveTransactions();
  render();
  form.reset();
  descriptionInput.focus();
});

clearAllButton.addEventListener("click", () => {
  if (transactions.length === 0) return;
  if (confirm("Are you sure you want to delete all transactions?")) {
    transactions = [];
    saveTransactions();
    render();
  }
});

render();
