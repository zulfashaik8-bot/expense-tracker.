# Expense Tracker Web Application

A beginner-friendly student mini project built using HTML, CSS, and JavaScript.

## Features
- Add income and expense transactions
- Automatically calculate balance, total income, and total expenses
- Delete individual transactions or clear all transactions
- Store transactions in browser local storage
- Responsive design for mobile and desktop

## Run locally
Open `index.html` in a web browser.

## Deploy with GitHub Pages
1. Upload `index.html`, `style.css`, and `script.js` to the root of a GitHub repository.
2. Open **Settings → Pages**.
3. Under build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
4. Your site will be available at `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

## Technologies
HTML5, CSS3, JavaScript, and browser local storage.
